import { type User, type InsertUser, type Generation, type InsertGeneration } from "@shared/schema";
import { randomUUID } from "crypto";
import bcrypt from "bcrypt";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserCredits(userId: string, credits: number): Promise<void>;
  
  // Generation methods
  getGenerationsByUser(userId: string): Promise<Generation[]>;
  getGeneration(id: string): Promise<Generation | undefined>;
  createGeneration(generation: InsertGeneration & { userId: string }): Promise<Generation>;
  updateGeneration(id: string, updates: Partial<Generation>): Promise<Generation>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private generations: Map<string, Generation>;

  constructor() {
    this.users = new Map();
    this.generations = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const hashedPassword = await bcrypt.hash(insertUser.password, 10);
    const user: User = { 
      ...insertUser, 
      id, 
      password: hashedPassword,
      credits: 100,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserCredits(userId: string, credits: number): Promise<void> {
    const user = this.users.get(userId);
    if (user) {
      user.credits = credits;
      this.users.set(userId, user);
    }
  }

  async getGenerationsByUser(userId: string): Promise<Generation[]> {
    return Array.from(this.generations.values())
      .filter((gen) => gen.userId === userId)
      .sort((a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0));
  }

  async getGeneration(id: string): Promise<Generation | undefined> {
    return this.generations.get(id);
  }

  async createGeneration(generation: InsertGeneration & { userId: string }): Promise<Generation> {
    const id = randomUUID();
    const newGeneration: Generation = {
      ...generation,
      id,
      mediaUrl: null,
      thumbnailUrl: null,
      status: "pending",
      replicateId: null,
      isEnhanced: generation.isEnhanced || false,
      originalGenerationId: generation.originalGenerationId || null,
      enhancementType: generation.enhancementType || null,
      createdAt: new Date(),
      metadata: generation.metadata || null,
    };
    this.generations.set(id, newGeneration);
    return newGeneration;
  }

  async updateGeneration(id: string, updates: Partial<Generation>): Promise<Generation> {
    const generation = this.generations.get(id);
    if (!generation) {
      throw new Error("Generation not found");
    }
    const updated = { ...generation, ...updates };
    this.generations.set(id, updated);
    return updated;
  }
}

export const storage = new MemStorage();
