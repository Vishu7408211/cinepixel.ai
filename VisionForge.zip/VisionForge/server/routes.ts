import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, loginSchema, insertGenerationSchema, enhanceContentSchema } from "@shared/schema";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import Replicate from "replicate";

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";
const REPLICATE_API_TOKEN = process.env.REPLICATE_API_TOKEN || "";

const replicate = new Replicate({
  auth: REPLICATE_API_TOKEN,
});

// Middleware to verify JWT token
const authenticateToken = (req: any, res: any, next: any) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: 'Access token required' });
  }

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) {
      return res.status(403).json({ message: 'Invalid token' });
    }
    req.user = user;
    next();
  });
};

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Auth routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists" });
      }

      const user = await storage.createUser(userData);
      const { password, ...userWithoutPassword } = user;
      
      const token = jwt.sign({ userId: user.id, email: user.email }, JWT_SECRET);
      
      res.json({ user: userWithoutPassword, token });
    } catch (error) {
      res.status(400).json({ message: "Invalid data", error });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const loginData = loginSchema.parse(req.body);
      
      const user = await storage.getUserByEmail(loginData.email);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const isValidPassword = await bcrypt.compare(loginData.password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const { password, ...userWithoutPassword } = user;
      const token = jwt.sign({ userId: user.id, email: user.email }, JWT_SECRET);
      
      res.json({ user: userWithoutPassword, token });
    } catch (error) {
      res.status(400).json({ message: "Invalid data", error });
    }
  });

  app.get("/api/auth/me", authenticateToken, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const { password, ...userWithoutPassword } = user;
      res.json({ user: userWithoutPassword });
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  // Generation routes
  app.post("/api/generate/image", authenticateToken, async (req: any, res) => {
    try {
      const { prompt, style = "photorealistic", aspectRatio = "1:1" } = req.body;
      
      if (!prompt) {
        return res.status(400).json({ message: "Prompt is required" });
      }

      // Check user credits
      const user = await storage.getUser(req.user.userId);
      if (!user || user.credits < 5) {
        return res.status(400).json({ message: "Insufficient credits" });
      }

      // Create generation record
      const generation = await storage.createGeneration({
        userId: req.user.userId,
        prompt,
        type: "image",
        metadata: JSON.stringify({ style, aspectRatio }),
      });

      // Deduct credits
      await storage.updateUserCredits(req.user.userId, user.credits - 5);

      // Start Replicate generation
      try {
        const output = await replicate.run(
          "black-forest-labs/flux-schnell",
          {
            input: {
              prompt: prompt,
              aspect_ratio: aspectRatio,
              num_outputs: 1,
              output_format: "webp",
              output_quality: 80,
            }
          }
        );

        const imageUrl = Array.isArray(output) ? output[0] : output;
        
        await storage.updateGeneration(generation.id, {
          status: "completed",
          mediaUrl: imageUrl as string,
          thumbnailUrl: imageUrl as string,
        });

        const updatedGeneration = await storage.getGeneration(generation.id);
        res.json({ generation: updatedGeneration });

      } catch (replicateError) {
        await storage.updateGeneration(generation.id, {
          status: "failed",
        });
        
        // Refund credits
        await storage.updateUserCredits(req.user.userId, user.credits);
        
        res.status(500).json({ message: "Image generation failed", error: replicateError });
      }

    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  app.post("/api/generate/video", authenticateToken, async (req: any, res) => {
    try {
      const { prompt, duration = "3", quality = "standard", mode = "text" } = req.body;
      
      if (!prompt && mode === "text") {
        return res.status(400).json({ message: "Prompt is required for text-to-video" });
      }

      // Check user credits
      const user = await storage.getUser(req.user.userId);
      if (!user || user.credits < 15) {
        return res.status(400).json({ message: "Insufficient credits" });
      }

      // Create generation record
      const generation = await storage.createGeneration({
        userId: req.user.userId,
        prompt,
        type: "video",
        metadata: JSON.stringify({ duration, quality, mode }),
      });

      // Deduct credits
      await storage.updateUserCredits(req.user.userId, user.credits - 15);

      // Start Replicate generation
      try {
        const output = await replicate.run(
          "minimax/video-01",
          {
            input: {
              prompt: prompt,
              num_frames: parseInt(duration) * 30, // 30 fps
            }
          }
        );

        const videoUrl = Array.isArray(output) ? output[0] : output;
        
        await storage.updateGeneration(generation.id, {
          status: "completed",
          mediaUrl: videoUrl as string,
          thumbnailUrl: videoUrl as string, // For videos, this would typically be a frame
        });

        const updatedGeneration = await storage.getGeneration(generation.id);
        res.json({ generation: updatedGeneration });

      } catch (replicateError) {
        await storage.updateGeneration(generation.id, {
          status: "failed",
        });
        
        // Refund credits
        await storage.updateUserCredits(req.user.userId, user.credits);
        
        res.status(500).json({ message: "Video generation failed", error: replicateError });
      }

    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  // Content Enhancement Route
  app.post("/api/enhance", authenticateToken, async (req: any, res) => {
    try {
      const enhanceData = enhanceContentSchema.parse(req.body);
      
      // Get the original generation
      const originalGeneration = await storage.getGeneration(enhanceData.generationId);
      if (!originalGeneration || originalGeneration.userId !== req.user.userId) {
        return res.status(404).json({ message: "Generation not found" });
      }

      if (originalGeneration.status !== "completed" || !originalGeneration.mediaUrl) {
        return res.status(400).json({ message: "Original generation must be completed first" });
      }

      // Check user credits based on enhancement type
      const creditCosts = {
        upscale: 10,
        refine: 8,
        style_transfer: 12,
        quality_boost: 6
      };

      const creditCost = creditCosts[enhanceData.enhancementType];
      const user = await storage.getUser(req.user.userId);
      if (!user || user.credits < creditCost) {
        return res.status(400).json({ message: "Insufficient credits" });
      }

      // Create enhancement generation record
      const enhancementGeneration = await storage.createGeneration({
        userId: req.user.userId,
        prompt: `Enhanced: ${originalGeneration.prompt}`,
        type: originalGeneration.type,
        isEnhanced: true,
        originalGenerationId: originalGeneration.id,
        enhancementType: enhanceData.enhancementType,
        metadata: JSON.stringify({ 
          originalId: originalGeneration.id,
          enhancement: enhanceData.enhancementType,
          creditCost 
        }),
      });

      // Deduct credits
      await storage.updateUserCredits(req.user.userId, user.credits - creditCost);

      // For demo purposes, we'll simulate enhancement by creating a new generation
      // In production, you would integrate with actual enhancement AI models
      try {
        // Simulate AI enhancement processing
        setTimeout(async () => {
          await storage.updateGeneration(enhancementGeneration.id, {
            status: "completed",
            mediaUrl: originalGeneration.mediaUrl, // In production, this would be the enhanced URL
            thumbnailUrl: originalGeneration.thumbnailUrl,
          });
        }, 2000);

        res.json({ generation: enhancementGeneration });

      } catch (enhancementError) {
        await storage.updateGeneration(enhancementGeneration.id, {
          status: "failed",
        });
        
        // Refund credits
        await storage.updateUserCredits(req.user.userId, user.credits);
        
        res.status(500).json({ message: "Enhancement failed", error: enhancementError });
      }

    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  app.get("/api/generations", authenticateToken, async (req: any, res) => {
    try {
      const generations = await storage.getGenerationsByUser(req.user.userId);
      res.json({ generations });
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  app.get("/api/generations/:id", authenticateToken, async (req: any, res) => {
    try {
      const generation = await storage.getGeneration(req.params.id);
      if (!generation || generation.userId !== req.user.userId) {
        return res.status(404).json({ message: "Generation not found" });
      }
      res.json({ generation });
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
