import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  credits: integer("credits").notNull().default(100),
  createdAt: timestamp("created_at").defaultNow(),
});

export const generations: any = pgTable("generations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  prompt: text("prompt").notNull(),
  type: text("type").notNull(), // 'image' | 'video'
  mediaUrl: text("media_url"),
  thumbnailUrl: text("thumbnail_url"),
  status: text("status").notNull().default("pending"), // 'pending' | 'generating' | 'completed' | 'failed'
  replicateId: text("replicate_id"),
  metadata: text("metadata"), // JSON string for additional data
  isEnhanced: boolean("is_enhanced").default(false),
  originalGenerationId: varchar("original_generation_id"),
  enhancementType: text("enhancement_type"), // 'upscale' | 'refine' | 'style_transfer' | 'quality_boost'
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  email: true,
  password: true,
});

export const insertGenerationSchema = createInsertSchema(generations).pick({
  prompt: true,
  type: true,
  metadata: true,
  isEnhanced: true,
  originalGenerationId: true,
  enhancementType: true,
});

export const enhanceContentSchema = z.object({
  generationId: z.string(),
  enhancementType: z.enum(['upscale', 'refine', 'style_transfer', 'quality_boost']),
});

export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertGeneration = z.infer<typeof insertGenerationSchema>;
export type Generation = typeof generations.$inferSelect;
export type LoginData = z.infer<typeof loginSchema>;
export type EnhanceContentData = z.infer<typeof enhanceContentSchema>;
