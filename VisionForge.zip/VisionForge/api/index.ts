import type { VercelRequest, VercelResponse } from '@vercel/node';
import express from 'express';
import { registerRoutes } from '../server/routes.js';

const app = express();

// Register all API routes
await registerRoutes(app);

// Export as Vercel serverless function
export default async function handler(req: VercelRequest, res: VercelResponse) {
  // Create Express-compatible request/response objects
  return new Promise((resolve, reject) => {
    app(req as any, res as any, (result: any) => {
      if (result instanceof Error) {
        reject(result);
      } else {
        resolve(result);
      }
    });
  });
}