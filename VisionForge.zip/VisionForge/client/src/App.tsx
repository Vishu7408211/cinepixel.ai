import { useState, useEffect } from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthGuard } from "@/components/auth-guard";
import { NavigationSidebar } from "@/components/navigation-sidebar";
import { TopHeader } from "@/components/top-header";
import LoginPage from "@/pages/login";
import Dashboard from "@/pages/dashboard";
import Gallery from "@/pages/gallery";
import NotFound from "@/pages/not-found";
import { authService } from "@/lib/auth";
import { User } from "@shared/schema";

function Router() {
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [user, setUser] = useState<Omit<User, 'password'> | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleNavigate = (page: string) => {
    setCurrentPage(page);
  };

  const handleLogout = () => {
    authService.logout();
    setUser(null);
  };

  const handleLoginSuccess = async () => {
    const currentUser = await authService.getCurrentUser();
    setUser(currentUser);
  };

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const closeSidebar = () => {
    setSidebarOpen(false);
  };

  const handleUserUpdate = (updatedUser: Omit<User, 'password'>) => {
    setUser(updatedUser);
  };

  return (
    <AuthGuard 
      fallback={<LoginPage onLoginSuccess={handleLoginSuccess} />}
    >
      {user && (
        <div className="min-h-screen bg-gradient-to-br from-slate-50 to-indigo-50">
          <NavigationSidebar
            user={user}
            currentPage={currentPage}
            onNavigate={handleNavigate}
            onLogout={handleLogout}
            isOpen={sidebarOpen}
            onClose={closeSidebar}
          />
          
          <div className="lg:ml-64 min-h-screen">
            <TopHeader 
              user={user}
              onToggleSidebar={toggleSidebar}
            />
            
            {currentPage === 'dashboard' && (
              <Dashboard 
                user={user} 
                onUserUpdate={handleUserUpdate}
                onNavigate={handleNavigate}
              />
            )}
            {currentPage === 'gallery' && <Gallery />}
          </div>
        </div>
      )}
    </AuthGuard>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
