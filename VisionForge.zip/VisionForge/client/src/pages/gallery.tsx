import { useState, useEffect } from "react";
import { Generation } from "@shared/schema";
import { MediaGallery } from "@/components/media-gallery";
import { authService } from "@/lib/auth";

export default function Gallery() {
  const [generations, setGenerations] = useState<Generation[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchGenerations = async () => {
    try {
      const token = authService.getToken();
      const response = await fetch('/api/generations', {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        setGenerations(data.generations);
      }
    } catch (error) {
      console.error('Failed to fetch generations:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchGenerations();
  }, []);

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
          <span className="ml-3 text-gray-600">Loading your gallery...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 bg-gradient-to-br from-slate-50 to-indigo-50 min-h-screen">
      <div className="mb-8">
        <h2 className="text-3xl font-bold bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 bg-clip-text text-transparent mb-2">
          Your CinePixel Gallery
        </h2>
        <p className="text-gray-600">Explore all your AI-generated masterpieces</p>
      </div>

      <MediaGallery 
        generations={generations}
        onRefresh={fetchGenerations}
        showFilters={true}
      />
    </div>
  );
}
