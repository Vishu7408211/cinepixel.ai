import { useState, useEffect } from "react";
import { Generation, User } from "@shared/schema";
import { ImageGenerationCard } from "@/components/image-generation-card";
import { VideoGenerationCard } from "@/components/video-generation-card";
import { MediaGallery } from "@/components/media-gallery";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { authService } from "@/lib/auth";

interface DashboardProps {
  user: Omit<User, 'password'>;
  onUserUpdate: (user: Omit<User, 'password'>) => void;
  onNavigate: (page: string) => void;
}

export default function Dashboard({ user, onUserUpdate, onNavigate }: DashboardProps) {
  const [generations, setGenerations] = useState<Generation[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const fetchGenerations = async () => {
    try {
      const token = authService.getToken();
      const response = await fetch('/api/generations', {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        setGenerations(data.generations);
      }
    } catch (error) {
      console.error('Failed to fetch generations:', error);
    }
  };

  const fetchUserData = async () => {
    try {
      const currentUser = await authService.getCurrentUser();
      if (currentUser) {
        onUserUpdate(currentUser);
      }
    } catch (error) {
      console.error('Failed to fetch user data:', error);
    }
  };

  useEffect(() => {
    fetchGenerations();
  }, []);

  const handleGenerationStart = () => {
    setIsLoading(true);
  };

  const handleGenerationComplete = () => {
    setIsLoading(false);
    fetchGenerations();
    fetchUserData(); // Refresh user data to update credits
  };

  const recentGenerations = generations
    .filter(gen => gen.status === 'completed')
    .slice(0, 3);

  return (
    <main className="p-6 bg-gradient-to-br from-slate-50 to-indigo-50 min-h-screen">
      <div className="mb-8">
        <h2 className="text-3xl font-bold bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 bg-clip-text text-transparent mb-2">
          Create with CinePixel AI
        </h2>
        <p className="text-gray-600">Transform your imagination into stunning visuals with our advanced AI models</p>
      </div>

      {/* Generation Tools */}
      <div className="grid lg:grid-cols-2 gap-8 mb-8">
        <ImageGenerationCard 
          onGenerationStart={handleGenerationStart}
          onGenerationComplete={handleGenerationComplete}
        />
        <VideoGenerationCard 
          onGenerationStart={handleGenerationStart}
          onGenerationComplete={handleGenerationComplete}
        />
      </div>

      {/* Recent Generations */}
      <Card className="shadow-2xl border-0 bg-white/80 backdrop-blur-sm">
        <div className="p-6 border-b border-gray-200/50">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
              Recent Creations
            </h3>
            <Button 
              variant="ghost" 
              onClick={() => onNavigate('gallery')}
              className="text-indigo-600 hover:text-indigo-700 font-semibold hover:bg-indigo-50 rounded-xl transition-all"
            >
              View Gallery
              <svg className="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </Button>
          </div>
        </div>

        <CardContent className="p-6">
          {isLoading && (
            <div className="flex items-center justify-center py-12">
              <div className="relative">
                <div className="animate-spin rounded-full h-12 w-12 border-4 border-indigo-200 border-t-indigo-600"></div>
                <div className="absolute inset-0 animate-pulse rounded-full bg-gradient-to-r from-indigo-400 to-purple-400 opacity-20"></div>
              </div>
              <span className="ml-3 text-gray-600 font-medium">Creating your masterpiece...</span>
            </div>
          )}
          
          {!isLoading && (
            <MediaGallery 
              generations={recentGenerations}
              onRefresh={fetchGenerations}
              showFilters={false}
            />
          )}
        </CardContent>
      </Card>
    </main>
  );
}
