import { useState } from "react";
import { Sparkles, Wand2, Palette, ArrowUp, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Generation, EnhanceContentData } from "@shared/schema";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface ContentEnhancementProps {
  generation: Generation;
  onEnhancementComplete?: (enhancedGeneration: Generation) => void;
}

const enhancementOptions = [
  {
    type: 'upscale' as const,
    name: 'AI Upscale',
    description: 'Increase resolution and clarity',
    icon: ArrowUp,
    credits: 10,
    color: 'bg-blue-500/10 text-blue-600 border-blue-500/20'
  },
  {
    type: 'refine' as const,
    name: 'AI Refine',
    description: 'Enhance details and sharpness',
    icon: Wand2,
    credits: 8,
    color: 'bg-purple-500/10 text-purple-600 border-purple-500/20'
  },
  {
    type: 'style_transfer' as const,
    name: 'Style Transfer',
    description: 'Apply artistic style improvements',
    icon: Palette,
    credits: 12,
    color: 'bg-pink-500/10 text-pink-600 border-pink-500/20'
  },
  {
    type: 'quality_boost' as const,
    name: 'Quality Boost',
    description: 'Overall quality enhancement',
    icon: Sparkles,
    credits: 6,
    color: 'bg-green-500/10 text-green-600 border-green-500/20'
  }
];

export default function ContentEnhancement({ generation, onEnhancementComplete }: ContentEnhancementProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const enhanceMutation = useMutation({
    mutationFn: async (data: EnhanceContentData) => {
      return apiRequest('/api/enhance', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    },
    onSuccess: (enhancedGeneration) => {
      toast({
        title: "Enhancement Started!",
        description: "Your content is being enhanced. Check your gallery for updates.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/generations'] });
      onEnhancementComplete?.(enhancedGeneration);
    },
    onError: (error: any) => {
      toast({
        title: "Enhancement Failed",
        description: error.message || "Failed to enhance content. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleEnhance = (enhancementType: EnhanceContentData['enhancementType']) => {
    enhanceMutation.mutate({
      generationId: generation.id,
      enhancementType,
    });
  };

  // Don't show enhancement options for already enhanced content
  if (generation.isEnhanced) {
    return (
      <Card className="glass-effect border-amber-500/20">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-sm">
            <Sparkles className="h-4 w-4 text-amber-500" />
            Enhanced Content
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">
            This content has already been enhanced with{' '}
            <Badge variant="secondary" className="ml-1">
              {generation.enhancementType?.replace('_', ' ')}
            </Badge>
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="glass-effect hover-glow transition-all duration-300">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 cinepixel-text-gradient">
          <Sparkles className="h-5 w-5" />
          One-Click Enhancement
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Instantly improve your content with AI-powered enhancements
        </p>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {enhancementOptions.map((option) => {
            const Icon = option.icon;
            return (
              <Button
                key={option.type}
                variant="outline"
                className={`h-auto p-4 flex flex-col items-start gap-2 ${option.color} hover:scale-105 transition-all duration-200`}
                onClick={() => handleEnhance(option.type)}
                disabled={enhanceMutation.isPending}
              >
                <div className="flex items-center justify-between w-full">
                  <div className="flex items-center gap-2">
                    <Icon className="h-4 w-4" />
                    <span className="font-medium text-sm">{option.name}</span>
                  </div>
                  <Badge variant="secondary" className="text-xs">
                    {option.credits} credits
                  </Badge>
                </div>
                <p className="text-xs text-left text-muted-foreground">
                  {option.description}
                </p>
                {enhanceMutation.isPending && (
                  <Loader2 className="h-3 w-3 animate-spin" />
                )}
              </Button>
            );
          })}
        </div>
        
        <div className="mt-4 p-3 rounded-lg bg-gradient-to-r from-indigo-500/10 to-purple-500/10 border border-indigo-500/20">
          <div className="flex items-center gap-2 text-sm font-medium text-indigo-600 dark:text-indigo-400">
            <Sparkles className="h-4 w-4" />
            Pro Tip
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            Enhanced content will appear as a new generation in your gallery, preserving your original.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}