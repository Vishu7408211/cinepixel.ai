import { useState, useEffect } from "react";
import { Generation } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { authService } from "@/lib/auth";
import { cn } from "@/lib/utils";
import EnhancementButton from "./enhancement-button";
import { Badge } from "@/components/ui/badge";
import { Sparkles, Download, Wand2 } from "lucide-react";

interface MediaGalleryProps {
  generations: Generation[];
  onRefresh: () => void;
  showFilters?: boolean;
}

export function MediaGallery({ generations, onRefresh, showFilters = false }: MediaGalleryProps) {
  const [filter, setFilter] = useState<'all' | 'image' | 'video'>('all');
  const [sort, setSort] = useState<'newest' | 'oldest'>('newest');
  const [view, setView] = useState<'grid' | 'list'>('grid');
  const { toast } = useToast();

  const filteredGenerations = generations
    .filter(gen => filter === 'all' || gen.type === filter)
    .filter(gen => gen.status === 'completed')
    .sort((a, b) => {
      const aTime = a.createdAt?.getTime() || 0;
      const bTime = b.createdAt?.getTime() || 0;
      return sort === 'newest' ? bTime - aTime : aTime - bTime;
    });

  const handleDownload = async (generation: Generation) => {
    if (!generation.mediaUrl) return;
    
    try {
      const response = await fetch(generation.mediaUrl);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.style.display = 'none';
      a.href = url;
      a.download = `ai-${generation.type}-${generation.id}.${generation.type === 'image' ? 'webp' : 'mp4'}`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "Downloaded",
        description: `${generation.type} saved to your device`,
      });
    } catch (error) {
      toast({
        title: "Download failed",
        description: "Unable to download the file",
        variant: "destructive",
      });
    }
  };

  if (generations.length === 0) {
    return (
      <Card>
        <CardContent className="p-12 text-center">
          <svg className="w-16 h-16 text-gray-400 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
          </svg>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">No generations yet</h3>
          <p className="text-gray-600">Start creating images and videos to see them here!</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {showFilters && (
        <Card>
          <CardContent className="p-6">
            <div className="flex flex-wrap items-center gap-4">
              <div className="flex items-center space-x-2">
                <label className="text-sm font-medium text-gray-700">Filter by:</label>
                <Select value={filter} onValueChange={(value: any) => setFilter(value)}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="image">Images</SelectItem>
                    <SelectItem value="video">Videos</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex items-center space-x-2">
                <label className="text-sm font-medium text-gray-700">Sort by:</label>
                <Select value={sort} onValueChange={(value: any) => setSort(value)}>
                  <SelectTrigger className="w-36">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="newest">Newest First</SelectItem>
                    <SelectItem value="oldest">Oldest First</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="ml-auto">
                <div className="flex items-center space-x-2 bg-gray-100 rounded-lg p-1">
                  <button
                    onClick={() => setView('grid')}
                    className={cn(
                      "p-2 rounded-md transition-colors",
                      view === 'grid' ? "bg-white shadow-sm text-gray-700" : "text-gray-500 hover:text-gray-700"
                    )}
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
                    </svg>
                  </button>
                  <button
                    onClick={() => setView('list')}
                    className={cn(
                      "p-2 rounded-md transition-colors",
                      view === 'list' ? "bg-white shadow-sm text-gray-700" : "text-gray-500 hover:text-gray-700"
                    )}
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 10h16M4 14h16M4 18h16" />
                    </svg>
                  </button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <div className={cn(
        "grid gap-6",
        view === 'grid' 
          ? "grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4"
          : "grid-cols-1"
      )}>
        {filteredGenerations.map((generation) => (
          <Card key={generation.id} className="group overflow-hidden hover:shadow-lg transition-all">
            <div className="relative">
              {generation.mediaUrl && (
                <>
                  {generation.type === 'image' ? (
                    <img 
                      src={generation.mediaUrl} 
                      alt={generation.prompt}
                      className="w-full h-64 object-cover"
                    />
                  ) : (
                    <video 
                      src={generation.mediaUrl}
                      className="w-full h-64 object-cover"
                      muted
                      loop
                      onMouseEnter={(e) => e.currentTarget.play()}
                      onMouseLeave={(e) => e.currentTarget.pause()}
                    />
                  )}
                </>
              )}
              
              <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all" />
              
              {generation.type === 'video' && (
                <div className="absolute top-3 left-3">
                  <span className="bg-blue-500 text-white px-2 py-1 rounded-lg text-xs font-semibold">
                    <svg className="w-3 h-3 inline mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.828 14.828a4 4 0 01-5.656 0M9 10h1m4 0h1m-6 4h8m-6-2h2a1 1 0 001-1V9a1 1 0 00-1-1H9a1 1 0 00-1 1v2a1 1 0 001 1z" />
                    </svg>
                    Video
                  </span>
                </div>
              )}
              
              <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity">
                <Button
                  size="sm"
                  variant="secondary"
                  onClick={() => handleDownload(generation)}
                  className="bg-white bg-opacity-90 hover:bg-opacity-100 shadow-lg"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                </Button>
              </div>
            </div>
            
            <CardContent className="p-4 space-y-3">
              <div className="flex items-start justify-between">
                <p className="text-sm text-gray-600 line-clamp-2 flex-1">
                  {generation.prompt}
                </p>
                {generation.isEnhanced && (
                  <Badge variant="secondary" className="ml-2 bg-gradient-to-r from-purple-500/10 to-pink-500/10 text-purple-700 border-purple-200">
                    <Sparkles className="h-3 w-3 mr-1" />
                    Enhanced
                  </Badge>
                )}
              </div>
              
              <div className="flex items-center justify-between text-xs text-gray-500">
                <span className="capitalize">{generation.type}</span>
                <span>
                  {generation.createdAt 
                    ? new Date(generation.createdAt).toLocaleDateString()
                    : 'Unknown date'
                  }
                </span>
              </div>

              {/* Enhanced content shows origin info */}
              {generation.isEnhanced && generation.enhancementType && (
                <div className="flex items-center gap-2 text-xs text-purple-600">
                  <Wand2 className="h-3 w-3" />
                  <span className="capitalize">{generation.enhancementType.replace('_', ' ')}</span>
                </div>
              )}

              {/* Enhancement button for completed, non-enhanced content */}
              {!generation.isEnhanced && generation.status === 'completed' && generation.mediaUrl && (
                <div className="flex justify-center">
                  <EnhancementButton 
                    generation={generation}
                    onEnhancementComplete={() => onRefresh()}
                  />
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
