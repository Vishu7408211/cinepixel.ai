interface CinePixelLogoProps {
  size?: "sm" | "md" | "lg";
  showText?: boolean;
  className?: string;
}

export function CinePixelLogo({ size = "md", showText = true, className = "" }: CinePixelLogoProps) {
  const sizeClasses = {
    sm: "w-8 h-8",
    md: "w-10 h-10", 
    lg: "w-16 h-16"
  };

  const textSizeClasses = {
    sm: "text-lg",
    md: "text-xl",
    lg: "text-3xl"
  };

  return (
    <div className={`flex items-center space-x-3 ${className}`}>
      <div className={`${sizeClasses[size]} relative`}>
        <svg
          viewBox="0 0 100 100"
          className="w-full h-full"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Gradient definitions */}
          <defs>
            <linearGradient id="cinePixelGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#6366f1" />
              <stop offset="50%" stopColor="#8b5cf6" />
              <stop offset="100%" stopColor="#ec4899" />
            </linearGradient>
            <linearGradient id="cinePixelAccent" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#f59e0b" />
              <stop offset="100%" stopColor="#ef4444" />
            </linearGradient>
          </defs>
          
          {/* Outer ring representing film reel */}
          <circle
            cx="50"
            cy="50"
            r="45"
            fill="none"
            stroke="url(#cinePixelGradient)"
            strokeWidth="3"
            opacity="0.8"
          />
          
          {/* Inner film holes */}
          <circle cx="30" cy="30" r="3" fill="url(#cinePixelGradient)" opacity="0.6" />
          <circle cx="70" cy="30" r="3" fill="url(#cinePixelGradient)" opacity="0.6" />
          <circle cx="30" cy="70" r="3" fill="url(#cinePixelGradient)" opacity="0.6" />
          <circle cx="70" cy="70" r="3" fill="url(#cinePixelGradient)" opacity="0.6" />
          
          {/* Central play button/pixel */}
          <rect
            x="35"
            y="35"
            width="30"
            height="30"
            rx="6"
            fill="url(#cinePixelGradient)"
          />
          
          {/* Play triangle */}
          <polygon
            points="45,42 45,58 58,50"
            fill="white"
          />
          
          {/* Pixel grid overlay */}
          <rect x="42" y="42" width="4" height="4" fill="url(#cinePixelAccent)" opacity="0.7" />
          <rect x="54" y="42" width="4" height="4" fill="url(#cinePixelAccent)" opacity="0.7" />
          <rect x="48" y="54" width="4" height="4" fill="url(#cinePixelAccent)" opacity="0.7" />
          
          {/* Animated sparkles */}
          <circle cx="20" cy="50" r="1.5" fill="#fbbf24" opacity="0.8">
            <animate attributeName="opacity" values="0.3;1;0.3" dur="2s" repeatCount="indefinite" />
          </circle>
          <circle cx="80" cy="50" r="1.5" fill="#fbbf24" opacity="0.8">
            <animate attributeName="opacity" values="1;0.3;1" dur="2s" repeatCount="indefinite" />
          </circle>
          <circle cx="50" cy="20" r="1.5" fill="#fbbf24" opacity="0.8">
            <animate attributeName="opacity" values="0.3;1;0.3" dur="1.5s" repeatCount="indefinite" />
          </circle>
          <circle cx="50" cy="80" r="1.5" fill="#fbbf24" opacity="0.8">
            <animate attributeName="opacity" values="1;0.3;1" dur="1.5s" repeatCount="indefinite" />
          </circle>
        </svg>
      </div>
      
      {showText && (
        <h1 className={`font-bold bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 bg-clip-text text-transparent ${textSizeClasses[size]}`}>
          CinePixel
        </h1>
      )}
    </div>
  );
}