import { useState } from "react";
import { Sparkles, Wand2, Palette, ArrowUp, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Generation, EnhanceContentData } from "@shared/schema";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface EnhancementButtonProps {
  generation: Generation;
  onEnhancementComplete?: (enhancedGeneration: Generation) => void;
}

const enhancementOptions = [
  {
    type: 'upscale' as const,
    name: 'AI Upscale',
    icon: ArrowUp,
    credits: 10,
    color: 'text-blue-600'
  },
  {
    type: 'refine' as const,
    name: 'AI Refine',
    icon: Wand2,
    credits: 8,
    color: 'text-purple-600'
  },
  {
    type: 'style_transfer' as const,
    name: 'Style Transfer',
    icon: Palette,
    credits: 12,
    color: 'text-pink-600'
  },
  {
    type: 'quality_boost' as const,
    name: 'Quality Boost',
    icon: Sparkles,
    credits: 6,
    color: 'text-green-600'
  }
];

export default function EnhancementButton({ generation, onEnhancementComplete }: EnhancementButtonProps) {
  const [open, setOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const enhanceMutation = useMutation({
    mutationFn: async (data: EnhanceContentData) => {
      return apiRequest('/api/enhance', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    },
    onSuccess: (enhancedGeneration) => {
      toast({
        title: "Enhancement Started!",
        description: "Your content is being enhanced. Check your gallery for updates.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/generations'] });
      onEnhancementComplete?.(enhancedGeneration);
      setOpen(false);
    },
    onError: (error: any) => {
      toast({
        title: "Enhancement Failed",
        description: error.message || "Failed to enhance content. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleEnhance = (enhancementType: EnhanceContentData['enhancementType']) => {
    enhanceMutation.mutate({
      generationId: generation.id,
      enhancementType,
    });
  };

  if (generation.isEnhanced) {
    return null;
  }

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          size="sm"
          variant="outline"
          className="cinepixel-gradient text-white border-0 hover:opacity-90 transition-all duration-200"
        >
          <Sparkles className="h-3 w-3 mr-1" />
          Enhance
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-4" side="top">
        <div className="space-y-3">
          <div className="text-sm font-medium cinepixel-text-gradient">
            One-Click Enhancement
          </div>
          
          <div className="grid grid-cols-2 gap-2">
            {enhancementOptions.map((option) => {
              const Icon = option.icon;
              return (
                <Button
                  key={option.type}
                  variant="outline"
                  size="sm"
                  className="h-auto p-3 flex flex-col items-center gap-1 hover:scale-105 transition-all duration-200"
                  onClick={() => handleEnhance(option.type)}
                  disabled={enhanceMutation.isPending}
                >
                  <Icon className={`h-4 w-4 ${option.color}`} />
                  <span className="text-xs font-medium">{option.name}</span>
                  <Badge variant="secondary" className="text-xs">
                    {option.credits}
                  </Badge>
                  {enhanceMutation.isPending && (
                    <Loader2 className="h-3 w-3 animate-spin" />
                  )}
                </Button>
              );
            })}
          </div>
          
          <div className="text-xs text-muted-foreground text-center">
            Enhanced content will appear as a new generation
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
}